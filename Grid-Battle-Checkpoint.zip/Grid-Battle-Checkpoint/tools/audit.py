"""Inventory source ZIPs in place without exporting ROMs or game assets."""
import argparse
import csv
import hashlib
import io
import json
from collections import Counter
from pathlib import Path
from zipfile import ZipFile


def rows(archive, name):
    return list(csv.DictReader(io.StringIO(archive.read(name).decode("utf-8-sig"))))


def images(value):
    if isinstance(value, dict):
        if isinstance(value.get("image"), str):
            yield value["image"]
        for child in value.values():
            yield from images(child)
    elif isinstance(value, list):
        for child in value:
            yield from images(child)


def audit_master(archive, names):
    catalog = rows(archive, "catalog.csv")
    paths = {row["animation_path"] for row in catalog}
    frames = {name for name in names if name.startswith("Frames/") and name.endswith(".png")}
    identities = {row["visual_identity_candidate"] for row in catalog
                  if row["category"].startswith("Navis/") and row["visual_identity_candidate"]}
    references = set()
    for path in sorted(paths & names):
        references.update(f"Frames/{image}.png" for image in images(json.loads(archive.read(path))))
    return {
        "catalog_rows": len(catalog),
        "index_rows": len(rows(archive, "index.csv")),
        "unresolved_rows": len(rows(archive, "unresolved.csv")),
        "animation_match_rows": len(rows(archive, "exact_animation_matches.csv")),
        "categories": dict(Counter(row["category"].split("/")[0] for row in catalog)),
        "games": dict(Counter(row["game"] for row in catalog)),
        "navi_candidate_names": sorted(identities),
        "navi_candidate_sets": sum(row["category"].startswith("Navis/") for row in catalog),
        "missing_catalog_paths": sorted(paths - names),
        "frame_count": len(frames),
        "distinct_png_byte_hashes": len({hashlib.sha256(archive.read(path)).digest() for path in frames}),
        "missing_frame_references": sorted(references - names),
        "frames_without_catalog_reference": len(frames - references),
    }


def audit_rom(blob):
    return {
        "game_code": blob[0xAC:0xB0].decode("ascii", errors="replace"),
        "header_title": blob[0xA0:0xAC].decode("ascii", errors="replace").strip("\x00 "),
        "header_checksum_valid": len(blob) >= 0xC0 and
        (-sum(blob[0xA0:0xBD]) - 0x19) % 256 == blob[0xBD],
        "bytes": len(blob),
        "sha256": hashlib.sha256(blob).hexdigest(),
    }


def audit(path):
    with ZipFile(path) as archive:
        names = {item.filename for item in archive.infolist() if not item.is_dir()}
        result = {
            "archive": path.name,
            "crc_result": archive.testzip() or "passed",
            "entries": len(names),
            "extensions": dict(Counter(Path(name).suffix.lower() for name in names)),
            "script_paths": sorted(name for name in names if Path(name).suffix in {".py", ".js", ".sh", ".lua"}),
            "roms": {name: audit_rom(archive.read(name)) for name in sorted(names)
                     if name.lower().endswith(".gba")},
        }
        if path.name == "BN_Simulator_Asset_Revision.zip":
            result["master"] = audit_master(archive, names)
        return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_directory", type=Path)
    args = parser.parse_args()
    print(json.dumps([audit(path) for path in sorted(args.input_directory.glob("*.zip"))], indent=2, sort_keys=True))
