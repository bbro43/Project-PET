# Signal Yard and Battle Network input audit

Signal Yard is an original real-time grid battle prototype. The accompanying audit inventories the supplied Battle Network archives without exporting their assets.

Run from this directory with Python 3:

```sh
python3 -m http.server 8765 --bind 127.0.0.1
```

Open http://127.0.0.1:8765. Choose Relay or Coil and start a CPU Duel, Sentry Formation, or Survival battle. Use the arrow keys and Z/X or the touch controls. Movement and attack commands can be held together. Attack windup locks movement until the projectile releases. The prototype remembers the selected pilot when browser storage is available.

Run simulation tests with Node.js 18 or later:

```sh
node --test tests/*.mjs
node --check client.mjs
```

For browser smoke tests, install Playwright, provide Chromium via `CHROMIUM_PATH`, keep the local server running, and run `node tests/browser.cjs`.

To reproduce the archive audit, place the unchanged input ZIPs in a local directory:

```sh
python3 tools/audit.py /path/to/input-zips > documentation/audit.json
```

The audit report lists source files, ROM fingerprints, archive entry counts, and catalog checks. See the continuation checkpoint and completion tracker for scope and pending work.
